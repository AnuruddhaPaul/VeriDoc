---
title: VeriDoc
emoji: 🛡️
colorFrom: blue
colorTo: indigo
sdk: streamlit
app_file: app.py
pinned: false
short_description: PDF Q&A that verifies its own answers
---

# VeriDoc

A PDF question-answering chatbot that checks every claim in its answer against the document and says
"Not found in the document" instead of guessing. Source code and report:
https://github.com/AnuruddhaPaul/VeriDoc

Set the `GROQ_API_KEY` secret in the Space settings before using it.
